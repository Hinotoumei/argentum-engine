#!/usr/bin/env bash
set -euo pipefail

BASE_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
OVERRIDES="$BASE_DIR/overrides"
PATCH="$BASE_DIR/patches/focused-magic-gemstone.patch"
PINNED_COMMIT="e4fcc1621812670c58c001a80df9c71eced69a1c"

expected=(
  "mtg-sets/2025/src/main/kotlin/com/wingedsheep/mtg/sets/definitions/spm/cards/ExclusiveNightclub.kt"
  "mtg-sets/2003-2007/src/main/kotlin/com/wingedsheep/mtg/sets/definitions/tsp/cards/GemstoneCaverns.kt"
  "mtg-sets/2003-2007/src/main/kotlin/com/wingedsheep/mtg/sets/definitions/dis/cards/InfernalTutor.kt"
  "mtg-sets/2017-2022/src/main/kotlin/com/wingedsheep/mtg/sets/definitions/stx/cards/KasminaEnigmaSage.kt"
  "mtg-sets/2003-2007/src/main/kotlin/com/wingedsheep/mtg/sets/definitions/fut/cards/KeldonMegaliths.kt"
  "mtg-sets/2008-2016/src/main/kotlin/com/wingedsheep/mtg/sets/definitions/shm/cards/Manamorphose.kt"
  "mtg-sets/2003-2007/src/main/kotlin/com/wingedsheep/mtg/sets/definitions/sok/cards/OneWithNothing.kt"
  "mtg-sets/2017-2022/src/main/kotlin/com/wingedsheep/mtg/sets/definitions/stx/cards/PrismariCommand.kt"
  "mtg-sets/2008-2016/src/main/kotlin/com/wingedsheep/mtg/sets/definitions/dgm/cards/SireOfInsanity.kt"
)

for rel in "${expected[@]}"; do
  test -s "$OVERRIDES/$rel" || { echo "FAIL missing override: $rel" >&2; exit 1; }
done

test -s "$PATCH" || { echo "FAIL missing Gemstone patch" >&2; exit 1; }
git apply --numstat "$PATCH" >/dev/null

grep -Fq 'git apply --check /focused-magic-patches/focused-magic-gemstone.patch' "$BASE_DIR/Dockerfile"
grep -Fq 'COPY overrides/ /src/' "$BASE_DIR/Dockerfile"
grep -Fq 'CounterType.LUCK' "$OVERRIDES/mtg-sets/2003-2007/src/main/kotlin/com/wingedsheep/mtg/sets/definitions/tsp/cards/GemstoneCaverns.kt"
grep -Fq 'GemstoneCavernsExileContinuation' "$PATCH"
grep -Fq 'subclass(GemstoneCavernsExileContinuation::class)' "$PATCH"
grep -Fq 'playerId != newState.activePlayerId' "$PATCH"
grep -Fq 'Zone.EXILE' "$PATCH"

echo "PASS static package shape: 9 card overrides present"
echo "PASS Gemstone patch parses as a git patch"
echo "PASS Dockerfile fail-fast patch check + override copy hooks present"
echo "PASS Gemstone opening-hand/luck-counter/exile wiring markers present"

if [[ "${1:-}" == "--full-build" ]]; then
  tmp="$(mktemp -d)"
  trap 'rm -rf "$tmp"' EXIT
  echo "INFO cloning pinned Argentum $PINNED_COMMIT"
  git clone https://github.com/wingedsheep/argentum-engine.git "$tmp/argentum"
  git -C "$tmp/argentum" checkout "$PINNED_COMMIT"
  git -C "$tmp/argentum" apply --check "$PATCH"
  git -C "$tmp/argentum" apply "$PATCH"
  cp -a "$OVERRIDES"/. "$tmp/argentum"/
  (cd "$tmp/argentum" && ./gradlew :game-server:bootJar --no-daemon)
  echo "PASS full pinned Argentum bootJar build"
fi
