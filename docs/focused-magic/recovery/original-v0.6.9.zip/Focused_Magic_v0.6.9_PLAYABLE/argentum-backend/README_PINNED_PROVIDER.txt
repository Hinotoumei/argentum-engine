Focused Magic v0.6.8 — Argentum backend deployment

AUTHORITATIVE SOURCE
Repository: https://github.com/wingedsheep/argentum-engine
Pinned commit: e4fcc1621812670c58c001a80df9c71eced69a1c

WHY A BACKEND EXISTS
Focused Magic remains a static Cloudflare Pages frontend, but v0.6.8 match rules are server-authoritative. The browser connects to Argentum's /game WebSocket. The old local JavaScript engine is retained only as an explicit fallback/debug path when Argentum is disabled.

EXACT-DECK CONTRACT
Focused Magic uses two normal Argentum player seats instead of the upstream quick-game AI-deck shortcut. Seat 1 sends createGame with the exact player main deck + sideboard. Seat 2 sends joinGame with the exact Dimir main deck + sideboard and is driven only by Argentum legalActions/pendingDecision. This preserves the Dimir 60+15 list exactly.

BUILD THE PINNED BACKEND
The Focused Magic package now carries a narrow core patch plus card-definition overrides. The reproducible path is:
  cd argentum-backend
  ./validate_argentum_repair.sh --full-build

Equivalent manual steps:
  git clone https://github.com/wingedsheep/argentum-engine.git
  cd argentum-engine
  git checkout e4fcc1621812670c58c001a80df9c71eced69a1c
  git apply --check /path/to/focused-magic-gemstone.patch
  git apply /path/to/focused-magic-gemstone.patch
  cp -a /path/to/overrides/. ./
  ./gradlew :game-server:bootJar --no-daemon

Runtime prerequisites: Java 21. Accounts/Postgres and Redis caching can remain disabled for a basic game server; the upstream defaults allow that. Serve port 8080 and route /game (WebSocket) and /api to it over TLS.

MANDATORY RELEASE GATE
Open the Argentum Engine panel in Focused Magic and run “Run mandatory v0.6.5 assessment.” A release is not proven complete unless BOTH the new 60-card deck and the Page legacy 61+2 deck are admitted against the exact Dimir 60+15 deck and the Dimir seat produces a non-pass action that is followed by an authoritative state update. Card parsing alone is not a pass.

ENVIRONMENT LIMITATION FOR THIS PACKAGE BUILD
This build environment could inspect the pinned source and validate the frontend adapter, but outbound DNS prevented a live connection to magic.wingedsheep.com and therefore prevented claiming a live provider/card-coverage PASS here. The in-app assessment deliberately fails closed on provider rejection and remains the live deployment acceptance gate.
