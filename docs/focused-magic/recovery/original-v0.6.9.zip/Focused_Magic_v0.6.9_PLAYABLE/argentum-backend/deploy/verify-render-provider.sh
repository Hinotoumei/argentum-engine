#!/usr/bin/env bash
set -euo pipefail
origin="${1:?usage: $0 https://provider.example [frontend-origin]}"
frontend_origin="${2:-https://focused-magic.example}"
origin="${origin%/}"
headers="$(mktemp)"
body="$(mktemp)"
trap 'rm -f "$headers" "$body"' EXIT

curl -fsSL -D "$headers" -o "$body" \
  -H "Origin: $frontend_origin" \
  -H 'Accept: application/json' \
  "$origin/api/cards"

python3 - "$headers" "$body" "$frontend_origin" <<'PY2'
import json,sys,re
headers_path,body_path,frontend_origin=sys.argv[1:4]
headers=open(headers_path,encoding='utf-8',errors='replace').read()
rows=json.load(open(body_path,encoding='utf-8'))
names={r.get('name') if isinstance(r,dict) else r for r in rows}
required=['Gemstone Caverns','Oscorp Industries']
missing=[x for x in required if x not in names]
if missing:
    raise SystemExit('FAIL missing provider identities: '+', '.join(missing))
m=re.search(r'(?im)^access-control-allow-origin:\s*(.+?)\s*$', headers)
if not m:
    raise SystemExit('FAIL /api/cards has no Access-Control-Allow-Origin header for browser preflight')
acao=m.group(1).strip()
if acao not in ('*', frontend_origin):
    raise SystemExit(f'FAIL unexpected Access-Control-Allow-Origin: {acao!r}')
print('PASS provider catalog contains Gemstone Caverns and Oscorp Industries')
print('PASS /api/cards browser CORS header:', acao)
PY2
